package com.edu;

public class JDBC 
{
public static void main(String[] args) 
{
	
}
}
