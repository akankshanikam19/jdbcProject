package com.prepar;

public class DatabaseOperation {

		public static void insertData()
		{
		 	
		}

}
